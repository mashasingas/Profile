## Instructions
This JAVA application supports Java 1.8 version
